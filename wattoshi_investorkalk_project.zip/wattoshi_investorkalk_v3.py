
import streamlit as st
import matplotlib.pyplot as plt
import pandas as pd

st.title("Wattoshi Investorkalk V3 - Placeholder")
